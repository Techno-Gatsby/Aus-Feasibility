Assistant (chat icon, bottom-right of the tracker)
1. Once: install Node.js and Claude Code (npm install -g @anthropic-ai/claude-code), run `claude` once and sign in.
2. Each time: double-click 'Start Assistant.cmd' in this folder and keep the window open while using the chat.
3. Keep 'claude-bridge.mjs' next to 'Start Assistant.cmd'.
