LS Attendance - phone app (Security Personnel Attendance)

The installed Android / iPhone app shows the phone page from your Azure site, so it updates
itself when the site is updated: deploy the azure/web folder (it already contains this page as
azure/web/worker/index.html). No reinstall is needed on the phones.

New in this version:
- Supervisors: camera button next to each person -> Scan report (attendance sheet, vehicle
  attendance, security violation, mispunch, medical). "Take photo" for paper pages, or
  "Photos / PDF" to attach PDF files (up to 15 MB each) or photos from the phone.
- Personnel: "Send medical report" on the home screen (photos or PDF).
- Without signal the report waits on the phone and is sent automatically later.
- Reports arrive in the tracker (Payroll -> Reports) at the next sync, filed under the person.

This file can also be opened directly in a phone browser for a quick look (demo data).
